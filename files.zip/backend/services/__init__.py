"""Shared CIRO backend services."""
