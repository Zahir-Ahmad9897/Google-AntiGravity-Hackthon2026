"""Structured CIRO agent implementations."""
